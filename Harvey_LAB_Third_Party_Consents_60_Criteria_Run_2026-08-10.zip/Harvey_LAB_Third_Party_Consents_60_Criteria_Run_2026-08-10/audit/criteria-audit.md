# Harvey Labs Criterion Audit - Third-Party Consents

- Task: Track Third-Party Consents and Draft Consent Solicitation Letters for Healthcare Diagnostics Acquisition
- Pinned repository commit: `55510f0e609ffa5cf6f5df17d9a813ce4bb33d0c`
- Self-audit result: **60/60 PASS_PROVISIONAL**
- Continuity: **273/273 -> 333/333 provisional**
- Scope note: This is an internal evidence-based self-audit, not an official Harvey score.

| ID | Criterion | Status | Evidence |
|---|---|---|---|
| C-001 | Tracker covers all 14 material contracts | PASS_PROVISIONAL | Consent Tracker!A5:R18 contains 14 numbered contract rows. |
| C-002 | Tracker includes counterparty name and contact for each entry | PASS_PROVISIONAL | Consent Tracker columns B and D list counterparty and key contact; all five required counterparties have named contacts. |
| C-003 | Tracker includes contract title and date for each entry | PASS_PROVISIONAL | Consent Tracker column C lists title and execution date for every row. |
| C-004 | Tracker includes assignment/CoC provision section references | PASS_PROVISIONAL | Consent Tracker column F gives contract/FAR section references, including all specified key provisions. |
| C-005 | Tracker includes triggering analysis for each contract | PASS_PROVISIONAL | Consent Tracker column G applies the 100% stock acquisition to each provision with reasoning. |
| C-006 | Five Required Consents correctly identified per Schedule 6.4 | PASS_PROVISIONAL | Required Consents!A5:K9 contains exactly Meridian, Apex, Trident, VNB, and Kessler-Braun. |
| C-007 | Tracker includes risk level and financial exposure columns | PASS_PROVISIONAL | Consent Tracker columns J and K provide risk and financial exposure. |
| C-008 | Tracker includes recommended approach/timing column | PASS_PROVISIONAL | Consent Tracker columns L and M provide approach, timing, and target date. |
| C-009 | ISSUE_001: Trident Competitor Restriction triggered by PulmoTech identified in tracker | PASS_PROVISIONAL | Trident row identifies PulmoTech at 32% against the 25% Competing Business threshold. |
| C-010 | ISSUE_001: Trident financial exposure quantified at $45-55M | PASS_PROVISIONAL | Trident row quantifies projected RespiPlex exposure at $45-55M. |
| C-011 | ISSUE_001: Trident consent letter addresses PulmoTech Competitor Restriction | PASS_PROVISIONAL | Letter 3 names PulmoTech, acknowledges the 32%/25% trigger, and requests consent plus tailored relief. |
| C-012 | ISSUE_002: VNB 35% CoC threshold identified and flagged | PASS_PROVISIONAL | VNB row identifies the >35% ownership threshold and the 100% acquisition trigger. |
| C-013 | ISSUE_002: VNB repayment/guaranty alternatives addressed | PASS_PROVISIONAL | VNB row and Required Consents sheet set out continuation, repayment, and parent-guaranty paths. |
| C-014 | ISSUE_002: VNB repayment cash flow impact noted ($351.4M) | PASS_PROVISIONAL | Executive Summary states $351.4M closing cash if the $11.4M VNB debt is repaid. |
| C-015 | ISSUE_002: VNB consent letter addresses 35% threshold and repayment options | PASS_PROVISIONAL | Letter 4 states the 35% threshold, $11.4M outstanding, and all three resolution paths. |
| C-016 | ISSUE_003: Apex 'null and void ab initio' language flagged | PASS_PROVISIONAL | Apex row flags Section 15.2 null-and-void-ab-initio consequence. |
| C-017 | ISSUE_003: Apex stock deal vs. assignment analysis included | PASS_PROVISIONAL | Apex trigger analysis explains why the express M&A/CoC assignment definition controls despite a stock deal. |
| C-018 | ISSUE_003: Apex consent letter references Section 15.1 and 15.2 | PASS_PROVISIONAL | Letter 2 expressly cites Sections 15.1 and 15.2. |
| C-019 | ISSUE_004: KB license 'personal to Licensee' with no merger carve-out flagged | PASS_PROVISIONAL | Kessler-Braun row flags personal-to-Licensee language, deemed assignment, and no merger carve-out. |
| C-020 | ISSUE_004: KB financial exposure includes licensed product revenue and redesign risk | PASS_PROVISIONAL | Kessler-Braun row gives $9.8M sales, $343K calculated royalty, $350K minimum, and redesign risk. |
| C-021 | ISSUE_004: KB consent letter addressed to Dr. Friedrich Braun | PASS_PROVISIONAL | Letter 5 is addressed to Dr. Friedrich Braun. |
| C-022 | ISSUE_005: Carolina Innovation Hub sublease two-level consent identified | PASS_PROVISIONAL | Carolina row identifies separate CIH and TPP/master-landlord approvals and missing Master Lease diligence. |
| C-023 | ISSUE_005: CIH sublease classified as Best Efforts Consent | PASS_PROVISIONAL | Carolina row is classified Best Efforts Consent. |
| C-024 | ISSUE_006: Nexgen 3PL lack of CoC carve-out analyzed | PASS_PROVISIONAL | Nexgen row analyzes the bare anti-assignment clause, absent CoC carve-out, and stock-survival no-trigger position. |
| C-025 | ISSUE_007: H&P termination fee of $270,000 identified | PASS_PROVISIONAL | Hensley & Park row calculates six months x $45K = $270K. |
| C-026 | ISSUE_007: H&P classified as economic consequence, not consent | PASS_PROVISIONAL | Hensley & Park row is classified Economic Consequence - No Consent. |
| C-027 | ISSUE_008: VA contract novation vs. name-change analysis | PASS_PROVISIONAL | VA row distinguishes stock-acquisition no-novation under FAR 42.1204 from name-change treatment under FAR 42.1205. |
| C-028 | ISSUE_009: Clearview Analytics correctly classified as not requiring consent | PASS_PROVISIONAL | Clearview row applies the M&A successor carve-out and does not classify a required consent. |
| C-029 | ISSUE_010: DataVault HIPAA/BAA implications flagged | PASS_PROVISIONAL | DataVault row flags BAA review and 45 C.F.R. §164.502(a) implications. |
| C-030 | ISSUE_011: Wellspring 'Restricted Entity' FDA debarment diligence flagged | PASS_PROVISIONAL | Wellspring row requires FDA-debarment diligence under 21 U.S.C. §335a. |
| C-031 | ISSUE_012: Pinnacle Lease omission from Schedule 6.4 flagged | PASS_PROVISIONAL | Pinnacle row flags its omission from Schedule 6.4 as a drafting gap. |
| C-032 | ISSUE_012: Recommendation to escalate or amend SPA for Pinnacle | PASS_PROVISIONAL | Pinnacle approach recommends SPA amendment or Ridgewell written risk acceptance. |
| C-033 | DISTRACTOR_001: Brightline Insurance correctly classified as no action required | PASS_PROVISIONAL | Brightline is classified No Action Required. |
| C-034 | DISTRACTOR_002: DataVault not classified as requiring consent | PASS_PROVISIONAL | DataVault is classified No Consent Required - HIPAA/BAA Action. |
| C-035 | DISTRACTOR_003: HSR filing not included as third-party consent | PASS_PROVISIONAL | No HSR item appears in the 14-contract consent register; legend separates regulatory actions from consents. |
| C-036 | DISTRACTOR_004: Wellspring classified as notification/acknowledgment, not full consent | PASS_PROVISIONAL | Wellspring is classified Notification/Acknowledgment, not Required Consent. |
| C-037 | Meridian consent letter drafted and addressed to Harold Tsung | PASS_PROVISIONAL | Letter 1 is addressed to Harold Tsung and requests Meridian consent. |
| C-038 | Meridian letter notes 30-day termination risk | PASS_PROVISIONAL | Letter 1 states the 30-day termination consequence. |
| C-039 | Meridian financial exposure noted as $18.7M annual spend / 38% COGS | PASS_PROVISIONAL | Meridian row states $18.7M annual spend and approximately 38% of COGS. |
| C-040 | All five consent letters include consent acknowledgment signature blocks | PASS_PROVISIONAL | Each of five letters ends with a counterparty CONSENTED AND AGREED signature block. |
| C-041 | All five consent letters on Ashford & Calloway LLP letterhead | PASS_PROVISIONAL | Each letter begins with Ashford & Calloway LLP letterhead. |
| C-042 | All five consent letters identify the transaction | PASS_PROVISIONAL | Each letter identifies Ridgewell, Luminos, the 100% stock acquisition, April 14 SPA, and June 30 target closing. |
| C-043 | Trident consent letter references Sections 14.1 and 14.2 | PASS_PROVISIONAL | Letter 3 cites Sections 14.1 and 14.2. |
| C-044 | Trident consent letter addressed to Samara Obi | PASS_PROVISIONAL | Letter 3 is addressed to Samara Obi. |
| C-045 | Apex consent letter notes NovaCare competitive risk | PASS_PROVISIONAL | Letter 2 notes Apex is evaluating a potential arrangement with NovaCare Diagnostics. |
| C-046 | Meridian tracker entry notes consent negotiation complexity | PASS_PROVISIONAL | Meridian row notes consolidation concerns, protracted negotiation risk, and early outreach. |
| C-047 | VNB Event of Default consequence noted | PASS_PROVISIONAL | VNB row states unconsented closing creates an Event of Default and acceleration risk under Section 8.01(i). |
| C-048 | Pinnacle lease consent standard correctly identified as NTURW | PASS_PROVISIONAL | Pinnacle row states consent may not be unreasonably withheld, conditioned, or delayed. |
| C-049 | KB royalty calculation noted (minimum royalty applies) | PASS_PROVISIONAL | Kessler-Braun row calculates 3.5% of $9.8M = $343K and notes the $350K minimum applies. |
| C-050 | Trident joint IP split noted (55/45) | PASS_PROVISIONAL | Trident special-issue/source analysis records joint IP at 55% Luminos / 45% Trident. |
| C-051 | VA contract classified as Notification Only | PASS_PROVISIONAL | VA row is classified Notification Only. |
| C-052 | Five consent letters are included in the deliverable | PASS_PROVISIONAL | The DOCX contains five letters on five rendered pages. |
| C-053 | Trident letter proposes compliance framework or waiver for Competitor Restriction | PASS_PROVISIONAL | Letter 3 proposes information barriers, access controls, need-to-know protocols, annual certification, and tailored waiver/narrowing. |
| C-054 | Tracker assigns Critical or High risk to Meridian | PASS_PROVISIONAL | Meridian risk is Critical. |
| C-055 | Tracker assigns Critical or High risk to Trident | PASS_PROVISIONAL | Trident risk is Critical. |
| C-056 | KB consent letter notes potential royalty renegotiation risk | PASS_PROVISIONAL | Letter 5 identifies possible royalty-term discussion and expressly preserves against implied acceptance. |
| C-057 | Deliverable includes consent-tracker.xlsx | PASS_PROVISIONAL | consent-tracker.xlsx is present and passes archive integrity/render checks. |
| C-058 | Deliverable includes consent-solicitation-letters.docx | PASS_PROVISIONAL | consent-solicitation-letters.docx is present and passes archive integrity/five-page render checks. |
| C-059 | Apex financial exposure quantified ($12.5M-$14M minimum commitments and EEA exclusivity) | PASS_PROVISIONAL | Apex row states $12.5M 2024 and $14.0M 2025 minimum commitments plus exclusivity through 2028 in 14 EEA countries, UK, and Switzerland. |
| C-060 | Pinnacle lease contact identified as Maria Fontaine | PASS_PROVISIONAL | Pinnacle row identifies Maria Fontaine, Director of Leasing. |
