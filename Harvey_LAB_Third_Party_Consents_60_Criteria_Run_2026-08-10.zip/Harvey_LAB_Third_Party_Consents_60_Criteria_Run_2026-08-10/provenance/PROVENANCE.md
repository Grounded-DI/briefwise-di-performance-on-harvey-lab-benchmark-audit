# Provenance

- Source: `harvey-labs` canonical benchmark repository.
- Pinned commit: `55510f0e609ffa5cf6f5df17d9a813ce4bb33d0c`.
- Task path: `tasks/corporate-ma/track-third-party-consents`.
- Run date: 2026-08-10.
- Inputs were treated as read-only; SHA-256 values appear in `input-hashes.csv`.
- Deliverables were independently generated from the pinned task record and nine supplied sources.
