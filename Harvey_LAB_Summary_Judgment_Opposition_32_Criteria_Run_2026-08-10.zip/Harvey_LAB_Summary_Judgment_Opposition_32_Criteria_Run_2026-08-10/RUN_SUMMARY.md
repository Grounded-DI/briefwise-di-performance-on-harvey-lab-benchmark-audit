# Benchmark run summary

## Selection

- Task: **Analyze Counterparty's Motion for Summary Judgment — Issue Identification Memorandum**
- Slug: `litigation-dispute-resolution/analyze-counterpartys-motion-for-summary-judgment`
- Canonical repository: `https://github.com/harveyai/harvey-labs`
- Pinned commit: `55510f0e609ffa5cf6f5df17d9a813ce4bb33d0c`
- Runtime continuity: FastPath SOL High; Tier 18; DIP 0–166; declared ΔH 0.0041.
- Selection rationale: materially distinct dispositive-motion task with nine record files and 32 objective criteria testing contract interpretation, fact-dispute identification, expert reliability, damages, and opposition strategy.

## Output

- `deliverables/msj-issue-identification-memo.docx`
- Eight rendered pages; each page visually inspected after the final pagination pass.
- Criterion-level self-audit: **32/32 provisional passes**.
- Continuity ledger: **182/182 → 214/214 provisional**.

## Status boundary

The criterion score is an internal reproducibility check against the public task JSON. It is not an official Harvey evaluation, endorsement, certification, or leaderboard result.
