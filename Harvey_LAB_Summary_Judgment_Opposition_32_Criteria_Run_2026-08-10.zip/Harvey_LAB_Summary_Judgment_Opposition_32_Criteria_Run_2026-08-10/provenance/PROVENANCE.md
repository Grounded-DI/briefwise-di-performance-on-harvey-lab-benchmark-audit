# Provenance

- Benchmark: Harvey Legal Agent Benchmark, `analyze-counterpartys-motion-for-summary-judgment`
- Repository: `https://github.com/harveyai/harvey-labs`
- Pinned commit: `55510f0e609ffa5cf6f5df17d9a813ce4bb33d0c`
- Acquisition date: 2026-08-10
- Deliverable: `msj-issue-identification-memo.docx`
- Source universe: the nine DOCX files listed in `input_sha256.txt`; no outside factual record was used.
- Deliverable SHA-256 at build: `ba29ea7a2142a1294c7e7e9af425e5b541c4cb932342e439977c37381a564371`
- Evaluation status: criterion-level self-audit only; not an official Harvey score or certification.
