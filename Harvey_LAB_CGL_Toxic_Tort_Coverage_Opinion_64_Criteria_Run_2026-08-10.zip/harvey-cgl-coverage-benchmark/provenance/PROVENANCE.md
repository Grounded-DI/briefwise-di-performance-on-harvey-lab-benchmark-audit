# Provenance

- Source repository: `harvey-labs`
- Pinned commit: `55510f0e609ffa5cf6f5df17d9a813ce4bb33d0c`
- Task: `tasks/insurance/draft-coverage-opinion-letter`
- Required deliverable: `coverage-opinion-letter.docx`
- Source inputs: six DOCX reference files plus `task.json`
- Input integrity: see `input-hashes.csv`
- Generated: 2026-08-10 (America/New_York)

The deliverable was generated from the pinned local task record. Source files were read without modification. Legal propositions were checked against the cited West Virginia authorities; the task's punitive-damages formulation was qualified to reflect the actual Hensley holding.
