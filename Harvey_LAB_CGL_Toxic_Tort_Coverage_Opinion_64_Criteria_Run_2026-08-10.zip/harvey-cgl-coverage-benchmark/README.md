# Harvey LAB — CGL Toxic-Tort Coverage Opinion Benchmark

## Result

- Required deliverable: `deliverables/coverage-opinion-letter.docx`
- Local criterion audit: **64/64 PASS_PROVISIONAL**
- Continuity: **437/437 → 501/501 provisional**
- Functional render: **12 pages**, all inspected

## Substantive result

The opinion recommends a defense under reservation of rights; applies the $5 million Products-Completed Operations Aggregate; analyzes pollution, known loss, expected/intended injury, occurrence count, punitive damages, subrogation waiver, contractual liability, recall, notice, independent counsel, and indemnity allocation; and supplies claims-handling actions tied to the record.

The result is a local self-audit, not an official Harvey LAB score.
