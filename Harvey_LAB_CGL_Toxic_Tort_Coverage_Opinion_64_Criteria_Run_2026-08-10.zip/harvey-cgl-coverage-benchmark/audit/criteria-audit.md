# Criterion Audit — CGL Toxic-Tort Coverage Opinion

Result: **64/64 PASS_PROVISIONAL**

This is a local evidence-based audit against the pinned task criteria, not an official Harvey LAB score.

| ID | Criterion | Status | Opinion anchor |
|---|---|---|---|
| C-001 | Correct identification of underlying case name | PASS_PROVISIONAL | Title / metadata |
| C-002 | Correct identification of underlying case number | PASS_PROVISIONAL | Title / metadata |
| C-003 | Correct identification of underlying court | PASS_PROVISIONAL | Title / metadata |
| C-004 | Correct policy number stated | PASS_PROVISIONAL | Title / metadata; § 3 |
| C-005 | Correct policy period stated | PASS_PROVISIONAL | Title / metadata; § 3 |
| C-006 | Per-occurrence limit correctly stated | PASS_PROVISIONAL | Executive Opinion; § 3 |
| C-007 | General aggregate limit correctly stated | PASS_PROVISIONAL | Executive Opinion; § 3 |
| C-008 | Products-completed operations aggregate correctly stated | PASS_PROVISIONAL | Executive Opinion; §§ 3, 5.5 |
| C-009 | Deductible amount correctly stated | PASS_PROVISIONAL | Executive Opinion; § 3 |
| C-010 | Deductible application to damages only noted | PASS_PROVISIONAL | Executive Opinion; §§ 3, 4 |
| C-011 | Total alleged exposure figure stated | PASS_PROVISIONAL | Executive Opinion; § 2.4 |
| C-012 | Individual plaintiff compensatory damages stated | PASS_PROVISIONAL | Executive Opinion; § 2.4 |
| C-013 | Ellerby cross-claim exposure stated | PASS_PROVISIONAL | Executive Opinion; § 2.4 |
| C-014 | Incident date correctly stated | PASS_PROVISIONAL | § 2.1 |
| C-015 | Valve model and quantity correctly stated | PASS_PROVISIONAL | § 2.1 |
| C-016 | Incident location correctly stated | PASS_PROVISIONAL | § 2.1 |
| C-017 | Released chemicals correctly identified | PASS_PROVISIONAL | § 2.1 |
| C-018 | Policy form correctly identified as occurrence form | PASS_PROVISIONAL | § 3 |
| C-019 | ISSUE_001: Pollution exclusion (CG 21 49) identified as coverage issue | PASS_PROVISIONAL | § 5.1 |
| C-020 | ISSUE_001: Complaint characterization vs. pollution exclusion language | PASS_PROVISIONAL | § 5.1 |
| C-021 | ISSUE_001: Industrial accident vs. traditional environmental pollution distinction | PASS_PROVISIONAL | § 5.1 |
| C-022 | ISSUE_001: West Virginia case law on pollution exclusion cited | PASS_PROVISIONAL | § 5.1 |
| C-023 | ISSUE_002: Known-loss / loss-in-progress doctrine analyzed | PASS_PROVISIONAL | § 5.2 |
| C-024 | ISSUE_002: January 22, 2024 Ogawa email identified as relevant | PASS_PROVISIONAL | §§ 2.3, 5.2 |
| C-025 | ISSUE_002: November 2022 prior claim identified as relevant | PASS_PROVISIONAL | §§ 2.3, 5.2 |
| C-026 | ISSUE_003: Expected or intended injury exclusion analyzed | PASS_PROVISIONAL | § 5.3 |
| C-027 | ISSUE_003: Cromdale Consulting report 'reasonably foreseeable' language addressed | PASS_PROVISIONAL | §§ 2.2, 5.3 |
| C-028 | ISSUE_003: Foreseeability vs. subjective intent/expectation distinction | PASS_PROVISIONAL | § 5.3 |
| C-029 | ISSUE_004: Number of occurrences analyzed | PASS_PROVISIONAL | § 5.4 |
| C-030 | ISSUE_004: Cause vs. effect test discussed | PASS_PROVISIONAL | § 5.4 |
| C-031 | ISSUE_004: Limits impact of single occurrence analyzed | PASS_PROVISIONAL | § 5.4 |
| C-032 | ISSUE_004: Limits impact of multiple occurrences analyzed | PASS_PROVISIONAL | § 5.4 |
| C-033 | ISSUE_004: Products-Completed Operations Aggregate as cap noted | PASS_PROVISIONAL | § 5.4 |
| C-034 | ISSUE_005: Claim correctly classified as products-completed operations | PASS_PROVISIONAL | § 5.5 |
| C-035 | ISSUE_005: Correct aggregate sublimit applied ($5M Prod-CO Agg) | PASS_PROVISIONAL | § 5.5 |
| C-036 | ISSUE_006: Punitive damages exclusion (SP-212) analyzed | PASS_PROVISIONAL | § 5.6 |
| C-037 | ISSUE_006: West Virginia insurability of punitive damages analyzed | PASS_PROVISIONAL | § 5.6 |
| C-038 | ISSUE_006: Direct vs. vicarious punitive damages distinction | PASS_PROVISIONAL | §§ 5.6, 8 |
| C-039 | ISSUE_007: Waiver of subrogation endorsement (CG 24 04) identified | PASS_PROVISIONAL | § 5.7 |
| C-040 | ISSUE_007: Interaction of waiver of subrogation with Ellerby cross-claim | PASS_PROVISIONAL | § 5.7 |
| C-041 | ISSUE_008: Contractual liability exclusion identified | PASS_PROVISIONAL | § 5.8 |
| C-042 | ISSUE_008: 'Insured contract' exception analyzed | PASS_PROVISIONAL | § 5.8 |
| C-043 | ISSUE_008: Contractual indemnity cap of $2M referenced | PASS_PROVISIONAL | § 5.8 |
| C-044 | ISSUE_009: Product recall exclusion (SP-107) analyzed | PASS_PROVISIONAL | § 5.9 |
| C-045 | ISSUE_009: Potential recall exposure for 1,450 valves flagged | PASS_PROVISIONAL | § 5.9 |
| C-046 | ISSUE_010: Late notice issue analyzed | PASS_PROVISIONAL | § 5.10 |
| C-047 | ISSUE_010: West Virginia notice-prejudice rule discussed | PASS_PROVISIONAL | § 5.10 |
| C-048 | ISSUE_010: January 2024 email as pre-incident awareness for notice | PASS_PROVISIONAL | §§ 5.10, 7 |
| C-049 | ISSUE_011: Duty to defend recommendation provided | PASS_PROVISIONAL | Executive Opinion; § 4 |
| C-050 | ISSUE_011: Reservation of rights recommended | PASS_PROVISIONAL | Executive Opinion; §§ 7–8 |
| C-051 | ISSUE_011: Eight corners / duty to defend standard discussed | PASS_PROVISIONAL | § 4 |
| C-052 | ISSUE_011: Independent counsel / Cumis counsel issue addressed | PASS_PROVISIONAL | § 4; § 8 |
| C-053 | West Virginia law applied as governing jurisdiction | PASS_PROVISIONAL | § 1 |
| C-054 | Defense costs outside the limits noted | PASS_PROVISIONAL | Executive Opinion; §§ 3–4 |
| C-055 | ECN 2021-034 weld specification change referenced | PASS_PROVISIONAL | § 2.2 |
| C-056 | Duty to indemnify analysis or position stated | PASS_PROVISIONAL | § 6 |
| C-057 | Named insured correctly identified as Ridgeline Manufacturing, Inc. | PASS_PROVISIONAL | § 3 |
| C-058 | Incident within policy period confirmed | PASS_PROVISIONAL | § 3 |
| C-059 | Number of individual plaintiffs correctly stated | PASS_PROVISIONAL | § 2.1 |
| C-060 | Types of alleged injuries stated | PASS_PROVISIONAL | § 2.1 |
| C-061 | Lead plaintiff Dobson's permanent lung damage claim noted | PASS_PROVISIONAL | § 2.1 |
| C-062 | Claims in underlying complaint substantially enumerated | PASS_PROVISIONAL | § 2.1 |
| C-063 | Recommendations section with at least two specific action items | PASS_PROVISIONAL | § 8 |
| C-064 | Tender letter date of May 6, 2024 referenced | PASS_PROVISIONAL | § 5.10; Source Index |
