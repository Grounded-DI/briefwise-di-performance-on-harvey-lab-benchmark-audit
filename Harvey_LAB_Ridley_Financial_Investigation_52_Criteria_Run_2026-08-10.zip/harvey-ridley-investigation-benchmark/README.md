# Harvey LAB — Ridley Financial Investigation Benchmark

## Result

- Deliverable: `deliverables/investigation-issue-memorandum.docx`
- Local criterion audit: **52/52 PASS_PROVISIONAL**
- Continuity: **333/333 → 385/385 provisional**
- Render: **8 pages**, functionally reviewed

## Substantive scope

The memorandum reconstructs two vendor kickback channels, analyzes a pre-announcement securities trade, evaluates PT Nusantara/Kominfo FCPA exposure, identifies an unauthorized related-party JV expenditure, and documents expense-report fraud. It reconciles questioned company payments without double counting downstream kickbacks and flags a numerical understatement in the background report.

## Package map

- `deliverables/` — final Word memorandum
- `audit/` — criterion matrix, content validation, continuity ledger
- `provenance/` — canonical task, source hashes, repository commit
- `qa/memo-render/` — reviewed PDF and page images

The criterion result is a local self-audit and is not an official Harvey LAB score.
