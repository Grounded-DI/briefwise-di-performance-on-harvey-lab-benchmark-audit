# Provenance

- Benchmark source: `harvey-labs`
- Canonical commit: `55510f0e609ffa5cf6f5df17d9a813ce4bb33d0c`
- Task path: `tasks/white-collar-defense-investigations/identify-suspicious-patterns-in-financial-transaction-records`
- Required deliverable: `investigation-issue-memorandum.docx`
- Source count: 10
- Criterion count: 52
- Preparation date: 2026-08-10

`input-hashes.csv` binds each source file to its SHA-256 digest. The original task specification is preserved as `task.json`.
