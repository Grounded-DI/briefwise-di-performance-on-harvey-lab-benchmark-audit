# Provenance

- Benchmark: Harvey Legal Agent Benchmark, `extract-key-admissions-from-deposition-transcript`
- Repository: `https://github.com/harveyai/harvey-labs`
- Pinned commit: `55510f0e609ffa5cf6f5df17d9a813ce4bb33d0c`
- Acquisition date: 2026-08-10
- Task instructions: Review the supplied deposition transcripts and supporting documents and prepare `admission-summary-memo.docx` with contradictions and recommended next steps.
- Source universe: the seven DOCX files listed in `input_sha256.txt`; no outside factual record was used.
- Deliverable SHA-256 at build: `70719fe05626fc25a4afa68e23f59b09e5aa3c3992e3595433919c8ff10d9dcd`
- Evaluation status: criterion-level self-audit only; not an official Harvey score or certification.
