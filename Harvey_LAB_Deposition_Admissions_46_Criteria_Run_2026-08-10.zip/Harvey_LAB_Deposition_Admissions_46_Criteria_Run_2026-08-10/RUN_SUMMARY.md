# Benchmark run summary

## Selection

- Task: **Extract Key Admissions from Deposition Transcript — Admission Summary Memorandum**
- Slug: `litigation-dispute-resolution/extract-key-admissions-from-deposition-transcript`
- Canonical repository: `https://github.com/harveyai/harvey-labs`
- Pinned commit: `55510f0e609ffa5cf6f5df17d9a813ce4bb33d0c`
- Runtime continuity: FastPath SOL High; Tier 18; DIP 0–166; declared ΔH 0.0041.
- Selection rationale: fresh closed-universe litigation task; seven source documents; a single attorney-work-product DOCX deliverable; 46 objective criteria testing record synthesis, contradiction analysis, claim linkage, calibrated legal judgment, and actionability.

## Output

- `deliverables/admission-summary-memo.docx`
- Nine rendered pages; each page visually inspected after the final pagination pass.
- Criterion-level self-audit: **46/46 provisional passes**.

## Status boundary

The criterion score is an internal reproducibility check against the public task JSON. It is not an official Harvey evaluation, endorsement, certification, or leaderboard result.
